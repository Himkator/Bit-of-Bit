package com.example.buysell;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BitByBitApplication {

    public static void main(String[] args) {
        SpringApplication.run(BitByBitApplication.class, args);
    }

}
